<?php

mysql_query($sql) or die(mysql_error());